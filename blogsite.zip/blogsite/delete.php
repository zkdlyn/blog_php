<?php

@include 'config.php';
session_start();

if (isset($_REQUEST["postID"])) {
    $postID = $_REQUEST["postID"];
    $select = "SELECT * FROM data WHERE postID = $postID";
    
    // Execute the query
    $query = mysqli_query($conn, $select);

    // Check if the query was successful
    if ($query) {
        // Fetch the result
        $result = mysqli_fetch_array($query);

        // Check if a row was found
        if ($result) {
            // Perform the delete
            $delete_post_query = "DELETE FROM data WHERE postID=$postID LIMIT 1";
            mysqli_query($conn, $delete_post_query);
        }
    }
    header("Location: user_page.php");
    exit();
}
?>